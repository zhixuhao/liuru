[
    {ResourceId: 'r1', StartDate : "2011-09-01T07:00", EndDate : "2011-09-01T12:00"},
    {ResourceId: 'r1', StartDate : "2011-09-01T14:00", EndDate : "2011-09-01T16:00", Cls : 'optimal'},
    {ResourceId: 'r2', StartDate : "2011-09-01T08:00", EndDate : "2011-09-01T18:00"},
    {ResourceId: 'r3', StartDate : "2011-09-01T08:00", EndDate : "2011-09-01T17:00"},
    {ResourceId: 'r5', StartDate : "2011-09-01T09:30", EndDate : "2011-09-01T18:00"},
    {ResourceId: 'r6', StartDate : "2011-09-01T08:00", EndDate : "2011-09-01T17:00"},
    {ResourceId: 'r73', StartDate : "2011-09-01T10:15", EndDate : "2011-09-01T17:00"},
    {ResourceId: 'r17', StartDate : "2011-09-01T10:00", EndDate : "2011-09-01T16:00"}
]