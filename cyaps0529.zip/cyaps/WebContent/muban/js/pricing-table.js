/* ===== Tooltips ===== */

$('#bonus-tip').tooltip();